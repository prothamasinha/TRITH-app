const API_BASE = "http://localhost:3000";

const container = document.getElementById("pendingOrdersContainer");
const msg = document.getElementById("approvalMsg");
const searchInput = document.getElementById("approvalSearch");

let pendingOrders = [];

function showMsg(type, text) {
  msg.innerHTML = `<div class="alert alert-${type}" role="alert">${text}</div>`;
}

async function loadPendingOrders() {
  try {
    const res = await fetch(`${API_BASE}/orders/pending`);
    if (!res.ok) throw new Error("GET /orders/pending failed");
    pendingOrders = await res.json();
  } catch (err) {
    const allOrders = JSON.parse(localStorage.getItem("orders")) || [];
    pendingOrders = allOrders.filter(order => order.status === "pending");
    showMsg("warning", "Backend not available. Loaded pending orders from localStorage.");
  }

  renderPendingOrders(pendingOrders);
}

function renderPendingOrders(list) {
  container.innerHTML = "";

  if (list.length === 0) {
    container.innerHTML = `<div class="text-muted">No pending orders.</div>`;
    return;
  }

  list.forEach(order => {
    const itemText = order.items
      .map(item => `${item.description} x${item.quantity}`)
      .join(", ");

    const col = document.createElement("div");
    col.className = "col-md-6";

    col.innerHTML = `
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">${order.id}</h5>
          <p class="mb-1"><strong>Status:</strong> <span class="badge text-bg-warning">pending</span></p>
          <p class="mb-1"><strong>Date:</strong> ${new Date(order.createdAt).toLocaleString()}</p>
          <p class="mb-1"><strong>Customer:</strong> ${order.customer.name} (${order.customer.email})</p>
          <p class="mb-2"><strong>Items:</strong> ${itemText}</p>
          <p class="mb-3"><strong>Total:</strong> $${Number(order.total).toFixed(2)}</p>

          <div class="d-flex gap-2">
            <button class="btn btn-success btn-sm" onclick="updateOrderStatus('${order.id}', 'approved')">Approve</button>
            <button class="btn btn-danger btn-sm" onclick="updateOrderStatus('${order.id}', 'declined')">Decline</button>
          </div>
        </div>
      </div>
    `;

    container.appendChild(col);
  });
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    const res = await fetch(`${API_BASE}/orders/${orderId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ status: newStatus })
    });

    if (!res.ok) throw new Error("PUT failed");
  } catch (err) {
    const allOrders = JSON.parse(localStorage.getItem("orders")) || [];
    const updated = allOrders.map(order => {
      if (order.id === orderId) {
        return { ...order, status: newStatus };
      }
      return order;
    });
    localStorage.setItem("orders", JSON.stringify(updated));
  }

  showMsg("success", `Order ${orderId} updated to ${newStatus}.`);
  loadPendingOrders();
}

searchInput.addEventListener("input", function () {
  const keyword = this.value.toLowerCase();

  const filtered = pendingOrders.filter(order => {
    const itemText = order.items.map(item => item.description).join(" ").toLowerCase();

    return (
      order.id.toLowerCase().includes(keyword) ||
      order.customer.name.toLowerCase().includes(keyword) ||
      itemText.includes(keyword)
    );
  });

  renderPendingOrders(filtered);
});

loadPendingOrders();