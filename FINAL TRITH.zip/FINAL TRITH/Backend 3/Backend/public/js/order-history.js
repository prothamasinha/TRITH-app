const API_BASE = "http://localhost:3000";

const tbody = document.getElementById("orderHistoryTbody");
const historySearch = document.getElementById("historySearch");
const historyMsg = document.getElementById("historyMsg");

let orders = [];

function badgeClass(status) {
  if (status === "approved") return "text-bg-success";
  if (status === "declined") return "text-bg-danger";
  return "text-bg-warning";
}

function showMsg(type, text) {
  historyMsg.innerHTML = `<div class="alert alert-${type}" role="alert">${text}</div>`;
}

function renderOrders(list) {
  tbody.innerHTML = "";

  if (list.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center text-muted">No orders found.</td>
      </tr>
    `;
    return;
  }

  list.forEach(order => {
    const details = order.items
      .map(item => `${item.description} x${item.quantity}`)
      .join(", ");

    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${order.id}</td>
      <td><span class="badge ${badgeClass(order.status)}">${order.status}</span></td>
      <td>${new Date(order.createdAt).toLocaleString()}</td>
      <td>${details}</td>
      <td>$${Number(order.total).toFixed(2)}</td>
    `;
    tbody.appendChild(row);
  });
}

async function loadOrders() {
  try {
    const res = await fetch(`${API_BASE}/orders`);
    if (!res.ok) throw new Error("GET /orders failed");
    orders = await res.json();
  } catch (err) {
    orders = JSON.parse(localStorage.getItem("orders")) || [];
    showMsg("warning", "Backend not available. Loaded from localStorage.");
  }

  renderOrders(orders);
}

historySearch.addEventListener("input", function () {
  const keyword = this.value.toLowerCase();

  const filtered = orders.filter(order => {
    const itemText = order.items.map(item => item.description).join(" ").toLowerCase();

    return (
      order.id.toLowerCase().includes(keyword) ||
      order.status.toLowerCase().includes(keyword) ||
      itemText.includes(keyword)
    );
  });

  renderOrders(filtered);
});

loadOrders();