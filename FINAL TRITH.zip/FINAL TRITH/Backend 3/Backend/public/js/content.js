const form = document.getElementById("catalogForm");
const tbody = document.getElementById("catalogTbody");
const messageArea = document.getElementById("messageArea");

const packageIdInput = document.getElementById("packageId");
const titleInput = document.getElementById("title");
const categoryInput = document.getElementById("category");
const unitInput = document.getElementById("unit");
const priceInput = document.getElementById("price");
const infoInput = document.getElementById("info");

const submitBtn = document.getElementById("submitBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const clearStorageBtn = document.getElementById("clearStorageBtn");

const PRICE_MAP = {
  "Members Only": 0,
  "$": 199.99,
  "$$": 499.99,
  "$$$": 899.99
};

function normalizeCatalogItem(item) {
  const priceTier = item.priceTier || item.price || "Members Only";

  return {
    id: item.id || generatePackageId(),
    title: item.title || "Untitled Package",
    category: item.category || "",
    duration: item.duration || item.unit || "",
    priceTier: priceTier,
    priceValue: Number(item.priceValue ?? PRICE_MAP[priceTier] ?? 0),
    info: item.info || "-"
  };
}

let catalog = (JSON.parse(localStorage.getItem("catalog")) || []).map(normalizeCatalogItem);
let editId = null;

localStorage.setItem("catalog", JSON.stringify(catalog));

setNextPackageId();
renderCatalog();

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const title = titleInput.value.trim();
  const category = categoryInput.value;
  const unit = unitInput.value.trim();
  const price = priceInput.value;
  const info = infoInput.value.trim();

  if (!title || !category || !unit || !price) {
    showMessage("danger", "Please fill in all required fields.");
    return;
  }

  if (editId) {
    catalog = catalog.map(function (item) {
      if (item.id === editId) {
        return {
          ...item,
          title: title,
          category: category,
          duration: unit,
          priceTier: price,
          priceValue: PRICE_MAP[price] || 0,
          info: info || "-"
        };
      }
      return item;
    });

    showMessage("warning", "Package updated successfully.");
    editId = null;
    submitBtn.textContent = "Add to Catalog";
    cancelEditBtn.classList.add("d-none");
  } else {
    const newItem = {
      id: generatePackageId(),
      title: title,
      category: category,
      duration: unit,
      priceTier: price,
      priceValue: PRICE_MAP[price] || 0,
      info: info || "-"
    };

    catalog.push(newItem);
    showMessage("success", "Package added to catalog.");
  }

  localStorage.setItem("catalog", JSON.stringify(catalog));
  renderCatalog();
  form.reset();
  setNextPackageId();
});

function renderCatalog(filteredCatalog = catalog) {
  tbody.innerHTML = "";

  if (filteredCatalog.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center text-muted">No packages in catalog yet.</td>
      </tr>
    `;
    return;
  }

  filteredCatalog.forEach(function (item) {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${item.id}</td>
      <td>${item.title}</td>
      <td>${item.category}</td>
      <td>${item.duration}</td>
      <td>${item.priceTier}</td>
      <td>${item.info}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editItem('${item.id}')">Edit</button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteItem('${item.id}')">Delete</button>
      </td>
    `;

    tbody.appendChild(row);
  });
}

function generatePackageId() {
  return "PKG" + Date.now();
}

function setNextPackageId() {
  packageIdInput.value = generatePackageId();
}

function deleteItem(id) {
  catalog = catalog.filter(function (item) {
    return item.id !== id;
  });

  localStorage.setItem("catalog", JSON.stringify(catalog));
  renderCatalog();
  showMessage("danger", "Package deleted.");
  setNextPackageId();
}

function editItem(id) {
  const item = catalog.find(function (pkg) {
    return pkg.id === id;
  });

  if (!item) return;

  editId = id;

  packageIdInput.value = item.id;
  titleInput.value = item.title;
  categoryInput.value = item.category;
  unitInput.value = item.duration;
  priceInput.value = item.priceTier;
  infoInput.value = item.info === "-" ? "" : item.info;

  submitBtn.textContent = "Update Package";
  cancelEditBtn.classList.remove("d-none");

  showMessage("info", "Edit mode enabled.");
}

cancelEditBtn.addEventListener("click", function () {
  editId = null;
  form.reset();
  setNextPackageId();
  submitBtn.textContent = "Add to Catalog";
  cancelEditBtn.classList.add("d-none");
  showMessage("secondary", "Edit cancelled.");
});

clearStorageBtn.addEventListener("click", function () {
  localStorage.removeItem("catalog");
  catalog = [];
  renderCatalog();
  form.reset();
  editId = null;
  setNextPackageId();
  submitBtn.textContent = "Add to Catalog";
  cancelEditBtn.classList.add("d-none");
  showMessage("danger", "Catalog localStorage cleared.");
});

$("#searchInput").on("keyup", function () {
  const keyword = $(this).val().toLowerCase();

  const filtered = catalog.filter(function (item) {
    return (
      item.title.toLowerCase().includes(keyword) ||
      item.category.toLowerCase().includes(keyword)
    );
  });

  renderCatalog(filtered);
});

function showMessage(type, text) {
  messageArea.innerHTML = `
    <div class="alert alert-${type}" role="alert">
      ${text}
    </div>
  `;
}