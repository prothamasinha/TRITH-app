const API_BASE = "http://localhost:3000";

const form = document.getElementById("optionsForm");
const messageArea = document.getElementById("messageArea");

const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const packageNameInput = document.getElementById("packageName");
const dateInput = document.getElementById("date");
const travelersInput = document.getElementById("travelers");
const insuranceInput = document.getElementById("insurance");
const pickupInput = document.getElementById("pickup");
const paymentInput = document.getElementById("payment");
const notesInput = document.getElementById("notes");
const agreeInput = document.getElementById("agree");

const sumPackage = document.getElementById("sumPackage");
const sumTravelers = document.getElementById("sumTravelers");
const sumAddons = document.getElementById("sumAddons");
const sumPayment = document.getElementById("sumPayment");

const cart = JSON.parse(localStorage.getItem("cart")) || [];

function showMessage(type, text) {
  messageArea.innerHTML = `<div class="alert alert-${type}" role="alert">${text}</div>`;
}

function getAddons() {
  const addons = [];
  if (insuranceInput.checked) addons.push("Travel Insurance");
  if (pickupInput.checked) addons.push("Airport Pickup");
  return addons;
}

function updateSummary() {
  const packageText = cart.length
    ? cart.map(item => `${item.description} x${item.quantity}`).join(", ")
    : "(No package selected)";

  packageNameInput.value = packageText;
  sumPackage.textContent = packageText;
  sumTravelers.textContent = travelersInput.value || "1";

  const addons = getAddons();
  sumAddons.textContent = addons.length ? addons.join(", ") : "None";
  sumPayment.textContent = paymentInput.value || "-";
}

function getTotal() {
  return cart.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
}

updateSummary();

[travelersInput, paymentInput, insuranceInput, pickupInput].forEach(el => {
  el.addEventListener("change", updateSummary);
  el.addEventListener("input", updateSummary);
});

form.addEventListener("submit", async function (e) {
  e.preventDefault();
  form.classList.add("was-validated");

  if (!form.checkValidity()) {
    showMessage("danger", "Please complete all required fields.");
    return;
  }

  if (cart.length === 0) {
    showMessage("danger", "Your cart is empty.");
    return;
  }

  const order = {
    id: "ORD" + Date.now(),
    status: "pending",
    createdAt: new Date().toISOString(),
    customer: {
      name: nameInput.value.trim(),
      email: emailInput.value.trim()
    },
    options: {
      startDate: dateInput.value,
      travelers: Number(travelersInput.value),
      addons: getAddons(),
      payment: paymentInput.value,
      notes: notesInput.value.trim()
    },
    items: cart,
    total: getTotal()
  };

  try {
    const res = await fetch(`${API_BASE}/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(order)
    });

    if (!res.ok) {
      throw new Error("POST /orders failed");
    }

    await res.json();
  } catch (err) {
    const orders = JSON.parse(localStorage.getItem("orders")) || [];
    orders.unshift(order);
    localStorage.setItem("orders", JSON.stringify(orders));
  }

  localStorage.removeItem("cart");
  showMessage("success", "Order submitted successfully. Redirecting to Order History...");

  setTimeout(() => {
    window.location.href = "order-history.html";
  }, 900);
});