const form = document.getElementById("subscriberForm");
const tbody = document.getElementById("subscriberTbody");
const messageArea = document.getElementById("messageArea");

const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const ageInput = document.getElementById("age");
const affiliationInput = document.getElementById("affiliation");
const phoneInput = document.getElementById("phone");

let subscribers = JSON.parse(localStorage.getItem("subscribers")) || [];

renderSubscribers();

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const age = ageInput.value.trim();
  const affiliation = affiliationInput.value.trim();
  const phone = phoneInput.value.trim();

  if (!name || !email || !age || !affiliation) {
    showMessage("danger", "Please fill in all required fields.");
    return;
  }

  const subscriber = {
    id: Date.now(),
    name: name,
    email: email,
    age: age,
    affiliation: affiliation,
    phone: phone || "-"
  };

  subscribers.push(subscriber);
  localStorage.setItem("subscribers", JSON.stringify(subscribers));

  renderSubscribers();
  form.reset();
  showMessage("success", "Success! Your registration was submitted.");
});

function renderSubscribers() {
  tbody.innerHTML = "";

  if (subscribers.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted">No subscribers yet.</td>
      </tr>
    `;
    return;
  }

  subscribers.forEach(function (sub) {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${sub.name}</td>
      <td>${sub.email}</td>
      <td>${sub.age}</td>
      <td>${sub.affiliation}</td>
      <td>${sub.phone}</td>
      <td>
        <button class="btn btn-sm btn-danger" onclick="deleteSubscriber(${sub.id})">Delete</button>
      </td>
    `;

    tbody.appendChild(row);
  });
}

function deleteSubscriber(id) {
  subscribers = subscribers.filter(function (sub) {
    return sub.id !== id;
  });

  localStorage.setItem("subscribers", JSON.stringify(subscribers));
  renderSubscribers();
  showMessage("warning", "Subscriber deleted.");
}

function showMessage(type, text) {
  messageArea.innerHTML = `
    <div class="alert alert-${type}" role="alert">
      ${text}
    </div>
  `;
}