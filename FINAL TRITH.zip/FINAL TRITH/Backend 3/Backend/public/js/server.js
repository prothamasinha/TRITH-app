const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let orders = [];

app.get("/orders", (req, res) => {
  res.json(orders);
});

app.get("/orders/pending", (req, res) => {
  const pending = orders.filter(order => order.status === "pending");
  res.json(pending);
});

app.post("/orders", (req, res) => {
  const order = req.body;
  orders.unshift(order);
  res.status(201).json(order);
});

app.put("/orders/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const index = orders.findIndex(order => order.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Order not found" });
  }

  orders[index].status = status;
  res.json(orders[index]);
});

app.listen(PORT, () => {
  console.log(`TRITH backend running on http://localhost:${PORT}`);
});