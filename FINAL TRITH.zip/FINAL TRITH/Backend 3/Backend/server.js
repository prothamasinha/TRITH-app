const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, "orders.json");

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public"))); 

function readOrders() {
  try {
    const data = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(data || "[]");
  } catch {
    return [];
  }
}

function writeOrders(orders) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(orders, null, 2), "utf8");
}

app.get("/", (req, res) => res.send("Server is running"));

app.get("/orders/pending", (req, res) => {          
  const orders = readOrders();
  res.json(orders.filter((o) => o.status === "pending"));
});

app.get("/orders", (req, res) => {                  
  res.json(readOrders());
});

app.post("/orders", (req, res) => {
  const orders = readOrders();
  const newOrder = {
    id: "TR-" + Date.now(),
    name: req.body.name || "Guest",
    items: req.body.items || [],
    total: req.body.total || 0,
    date: req.body.date || new Date().toISOString().split("T")[0],
    status: "pending",
  };
  orders.push(newOrder);
  writeOrders(orders);
  res.json({ message: "Order created", order: newOrder });
});

app.put("/orders/:id", (req, res) => {
  const orders = readOrders();
  const index = orders.findIndex((o) => o.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Order not found" });
  orders[index].status = req.body.status;
  writeOrders(orders);
  res.json({ message: "Updated", order: orders[index] });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));